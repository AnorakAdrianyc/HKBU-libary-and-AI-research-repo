# Integration Plan: Second Brain (Energy Geography / ITS2005) × HKBU Library Research Support & Generative AI Guides

**Date:** 9 November 2026  
**Context:** Integrate the crawled, parsed, and indexed materials from the `10,23,2026_Second_Brain` branch (energy-geography repo) and the Google Drive shared pack (`1Rfg-fpVOS4WRwJJJ34c9DTNhkbSfQK4K`) with thinking/understanding layers for HKBU Library resources. Leverage `gest-grapgrag-prep`, `osint-canvas-skill-manager`, and `xlsx` skills.

**Core Project Spine (locked):**  
Access & schedule first (estate/building convenience) ≫ website AI as awareness edge DEMO only. Soft labels: DEMO | ARCHITECTURE | FUTURE | PLAN. CSDI = WHERE only. EPD 800+ application points ≠ bin sets. Quarantine invented n/% . Raise awareness of existing GREEN@COMMUNITY (12 Stations · 83 Stores · ~600 Spots) via university Living Labs + Gen Z+ digital entertainment.

## 1. Inventory & Structured Ingest of Second Brain Materials

**Primary sources:**
- Drive folder contents: `00-README-INDEX.md`, evidence sources (`A0-evidence-sources.md`), claim tables (`B-claim-table.md`), epistemic hedges (`D-epistemic.md`), deduction notes, design-thinking disciplines, mesh synthesis, posters (A0-poster-FINAL, PageA/B PDFs), proposal Part B, geojson (`04_csdi_green_stations_12.geojson`), and spreadsheets (baseline metrics, network composition, points vs bin sets, awareness channels, access-first spine).
- GitHub branch (when accessible): presumed wiki-style notes, indexes, raw/parsed sources, GraphRAG-ready nodes.

**Actions:**
- Export Drive Docs to Markdown; download Sheets as CSV and GeoJSON.
- Define GraphRAG schema (from gest-grapgrag-prep full mode):
  - **Nodes:** Claim, Source (CSDI/EPD/interview/literature), Station (OBJECTID, lat/lon, address), Metric, InterviewTheme, Hedge, Channel (awareness), Layer (ACCESS_SPINE / AI_EDGE / FUTURE).
  - **Edges:** supports, hedges, contradicts, located_at, measured_by, relates_to, advances (policy).
- Index with embeddings (local or Qwen-style) for semantic retrieval. Tag every assertion: Observed / Interpretation / Hypothesis / Unknown (osint-canvas contract).
- Maintain quarantine list (Doubao n=, Qualtrics %, measured staff-load cut, map⇒behaviour).

## 2. Augment with HKBU Library Research Support & Generative AI Tools

**Research Support services to activate:**
- **Research Data Services:** Analytics/visualization of CSDI stations, baseline metrics; RDM for the geojson + sheets (versioning, documentation).
- **Digital Scholarship Services / Grant:** Explore collaborative viz projects or Living Lab prototypes; potential grant framing for multi-stakeholder awareness.
- **Research Output Visibility & Impact + Open Access:** Plan for poster/proposal dissemination; copyright checks on EPD/CSDI data.
- **EndNote + Citing Sources:** Manage literature from library tools; APA/Chicago for course artifacts.
- **Academic Integrity (Turnitin / iThenticate):** Run drafts; enforce soft hedges and source attribution.
- **Subject/Topic Guides:** Cross-reference Geography, Environmental Studies, Transdisciplinary guides.

**Generative AI tools (from libguides/generative-ai and /list):**
- **LeapSpace** (replaces Scopus AI): Full-text synthesis on circular economy Living Labs, smart recycling pilots, Gen Z environmental communication, AI guidance systems. Generate referenced reports; identify collaborators/funding.
- **Consensus + Scite Assistant:** Quick paper summaries, citation context, key insights on contamination rebound, access barriers, gamification/awareness.
- **Elicit / Research Rabbit / Connected Papers:** Structured extraction of facts/events; visual paper graphs for related work on waste hierarchy, GIS for recycling points.
- **HKBU GenAI Platform / Perplexity / others:** Exploratory queries (with responsible use); presentation support via Gamma for refined posters.
- **Guidelines compliance:** Follow HKBU Principles for Generative AI in Teaching/Learning/Assessment and UNESCO quick-start. Do not upload proprietary e-resource full texts. Label AI-assisted sections. Prefer tools that provide citations.

**Workflow:** For each major topic (spatial WHERE, access spine, awareness channels, evaluation PLAN, rebound risks), query library AI tools → extract → cross-validate against Second Brain claims → update evidence ledger with source type + year + hedge status.

## 3. Skill-Driven Thinking & Understanding Layer

### gest-grapgrag-prep (Full Mode — recommended)
- Treat ITS2005 as GEST-adjacent (green tech, sustainability, smart systems, waste).
- Extract topics/LOs from proposal + course framing.
- Research by strict priority: textbooks → forums → 2023–2026 papers → industry/policy (EPD, CSDI, EMSD, IEA-style circular economy).
- Multi-hop GraphRAG reasoning: Station location → access friction → night guidance gap → contamination rebound risk → Living Lab multi-stakeholder design.
- Advanced: MoE routing (experts: Spatial/GIS, Policy/EPD, Social/Gen Z awareness, Tech/AI guidance, Systems/rebound). Cross-validation across source categories. Steerable alternative-thinking (e.g., “challenge the access-first spine”, “steelman pure tech solution”).
- Output: Structured notes + GraphRAG starter kit (schema, prompts) + embedding patterns.

### osint-canvas-skill-manager
- Business Model Canvas analysis of the proposed solution:
  - Customer segments (residents, Gen Z+, estate managers, uni incubators).
  - Value proposition (awareness of existing GREEN@ + guided access, not new infrastructure).
  - Channels (digital entertainment, website AI edge, events, HKTDC).
  - Key partners (EPD baseline, university Living Labs, stakeholders).
  - Evidence grid with Observed/Interpretation/Hypothesis tags.
- Spatial layer: Choropleth or station map from geojson (WHERE only; label limitations).
- Skill routing: Primary = this for canvas; support = gest-grapgrag-prep for deep research; xlsx for metrics.
- Automation policy: Prefer on-demand or low-frequency updates; no minute-level polling. Label simulated vs observed.

### xlsx Skill
- Clean and analyze spreadsheets:
  - `01_baseline_where_metrics`, `02_green_network_composition`, `03_points_vs_bin_sets_contrast` → contrast tables (points ≠ sets; LCQ verification notes).
  - `04_csdi_green_stations_12` + geojson → spatial summary.
  - `05_awareness_channels_demo`, `06_access_first_spine` → priority ranking and status dashboard.
- Produce formatted workbooks with claim-type filters, charts (hatched for PLAN only), and provenance columns.
- Export summary tables for poster refresh or proposal appendix.

## 4. Integration Architecture

```
[Drive + GitHub Second Brain] 
    → Parse/Index (claims, stations, hedges) 
    → GraphRAG nodes/edges 
        ↗ Cross-validate 
[Library AI Tools: LeapSpace, Consensus, Elicit, Research Rabbit] 
    → New literature/policy nodes 
        ↘ 
[Thinking Layer: multi-hop queries + MoE + alternative thinking + BMC canvas]
    → Outputs: Updated ledger, research notes, spatial dashboard, refined artifacts
```

- Query examples: “What evidence supports access-first over AI hero?”, “Literature on Living Labs for circular economy awareness in Asian cities”, “Hedge status of 800+ points claim”.
- Maintain soft DEMO honesty and critical reflection (AI mis-reads; awareness without ops capacity can rebound).

## 5. Recommended Cadence & Deliverables

| Phase | Actions | Deliverable | Tools/Skills |
|-------|---------|-------------|--------------|
| Ingest (Day 1) | Export Drive, define schema, initial graph | Markdown index + JSON graph stub | Drive tools, gest schema |
| Research Expand (Days 2–4) | LeapSpace/Consensus runs on 4–6 topics; cross-validate | Expanded evidence ledger | Library GenAI + gest |
| Analysis (Days 3–5) | xlsx on sheets; BMC canvas; station map | Metrics workbook + canvas readout + map | xlsx + osint-canvas |
| Thinking Layer (Ongoing) | Multi-hop queries, alternative views, MoE routing | Structured notes + steerable prompts | gest full mode |
| Artifact Refresh | Update poster/proposal with new hedges + cites | Refined A0 poster / Part B | All + integrity tools |
| Maintenance | Weekly claim check; on-demand research | Versioned knowledge base | Automation router (low frequency) |

**Immediate next steps:**
1. Confirm GitHub branch access (repo under AnorakAdrianyc may be private; connected account is anorakadrian).
2. Run lightweight gest-grapgrag-prep on the proposal framing.
3. Build BMC canvas for the Living Lab + awareness value proposition.
4. Analyze the six spreadsheets into a single metrics dashboard.
5. Query LeapSpace on “Living Labs for municipal recycling awareness Hong Kong / Greater Bay Area 2023–2026”.

This plan keeps the locked spine, epistemic discipline, and responsible AI use while turning the Second Brain into a living, cross-validated understanding system for the course and broader GEST-related work.
