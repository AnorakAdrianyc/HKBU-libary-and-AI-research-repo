# ITS 2005 Section 002 — Data visualisations and APA 7th reference list

**Poster:** Sorting Feels Slow, So the Normal Bin Wins  
**Course:** ITS 2005 Transdisciplinary Inquiries and Methodologies · Section 002 · Hong Kong Baptist University  
**File date:** 9 November 2026  
**What this file is:** the numbers on the A0 poster, drawn as charts, plus a reference list in APA 7th edition.  
**What this file is not:** a city-wide recycling rate, a pilot result, or a claim that the night-guidance screen has been installed.

Replace “Project team” in the dataset entry below with the group members’ names when those names are confirmed. They were not on the poster.

---

## How to read the numbers

Two different scales sit in this file. Do not add them together.

| Scale | What it measures | Source type | Status on the poster |
|---|---|---|---|
| Survey and interviews | Kwai Fong residents (n = 17) and GREEN@ Kwai Fong staff/residents (n = 8) | Team primary data | Direction only. Exploratory convenience sample. Not a Hong Kong rate. |
| GREEN@ network and 2024 waste statistics | Territory-wide programme size and municipal solid waste | Environmental Protection Department publications | Background. Not produced by this survey. |
| Pilot targets (−30%, ≥25%, −15%, 12 h → 24 h, 1 → n) | What a funded pilot would try to move | Team proposal | Not measured. Not results. |

Rounding used on the poster, checked here:

| Claim on the poster | Count | Exact share | Rounded figure used |
|---|---:|---:|---:|
| Do not know GREEN@ exists | 4 of 17 | 23.5% | 24% |
| Non-users name time or space as the barrier | 10 of 17 | 58.8% | 59% |
| Would use a fixed-time hub inside the estate | 14 of 17 | 82.4% | 82% |
| Rated that hub 4 or 5 out of 5 | 14 of 17 | 82.4% | shown as a count, not a second percentage |
| Mean rating for that hub | — | — | 4.06 / 5 (not recomputed; raw item scores were not in the poster file) |

The 82% card and the “14 of 17 rated 4 or 5” line are the same count. They are not two independent findings.

Barrier counts and channel counts **may overlap**. A person can name more than one barrier and more than one place they would notice the service. Those bars are mentions, not shares of 17 that sum to 100%.

---

## 1. Primary findings (team data)

In-text example: Of 17 Kwai Fong residents surveyed, 4 (24%) did not know GREEN@ existed, and 14 (82%) said they would use a fixed-time hub inside the estate (Project team, 2026).

### 1.1 Headline counts out of 17

```mermaid
xychart-beta
    title "Headline counts (n = 17 convenience sample)"
    x-axis ["Unaware of GREEN@", "Time or space barrier", "Would use estate hub", "Rated hub 4 or 5"]
    y-axis "Respondents (of 17)" 0 --> 17
    bar [4, 10, 14, 14]
```

| Finding | Count | Poster wording | Denominator |
|---|---:|---|---|
| Do not know GREEN@ exists | 4 | 24% | 17 |
| Name time or space as the barrier | 10 | 59% of non-users; poster also prints “10 of 17” | 17, as printed |
| Would use a fixed-time hub inside the estate | 14 | 82% | 17 |
| Rated that hub 4 or 5 | 14 | paired with mean 4.06 / 5 | 17 |
| Mean rating | 4.06 | out of 5 | item as fielded; raw scores not reprinted here |

Sample frame printed on the poster: Qualtrics survey of Kwai Fong residents; interviews at GREEN@ Kwai Fong on 27 October 2026 (n = 8); photographs at Tai Wai on 8 November 2026. Read n = 17 and n = 8 as direction, not as a city-wide rate (Project team, 2026).

### 1.2 Barriers named (counts can overlap)

```mermaid
xychart-beta
    title "Barriers named — mentions, not a partition of 17"
    x-axis ["Too far", "Hours", "Rules", "Timetable"]
    y-axis "Mentions" 0 --> 8
    bar [5, 3, 3, 2]
```

| Barrier | Mentions |
|---|---:|
| Too far | 5 |
| Hours | 3 |
| Rules | 3 |
| Timetable | 2 |
| Sum of mentions | 13 |

The sum is larger than any single person’s answer and is not a percentage base. Do not report “5/13 = 38% said too far.”

### 1.3 Where they would notice the service (more than one allowed)

```mermaid
xychart-beta
    title "Where they would notice it (of 17; more than one allowed)"
    x-axis ["Lobby", "WhatsApp", "Social"]
    y-axis "Mentions" 0 --> 14
    bar [12, 8, 2]
```

| Channel | Mentions (of 17) |
|---|---:|
| Lobby | 12 |
| WhatsApp | 8 |
| Social | 2 |
| Sum of mentions | 22 |

Lobby is the largest stated channel in this sample (12 of 17). That supports putting hours where the decision is made, at the bin and in the lobby. It does not show that a lobby poster has already changed behaviour.

### 1.4 Words from interviews (not percentages)

These are excerpts printed on the poster. They illustrate the hours problem. They are not coded frequencies.

> “When no staff are around, I feel confused.” — Resident (Project team, 2026)

> “I wish recycling points were open 24 hours.” — Resident (Project team, 2026)

### 1.5 One-sentence reading (already on the poster)

The barrier is not willingness. It is access, hours, and sorting confidence. All three can move without new hardware (Project team, 2026).

---

## 2. Methods at a glance

| Cell | What was done | When / where | n |
|---|---|---|---:|
| Survey | Qualtrics questionnaire, Kwai Fong residents | Kwai Fong | 17 |
| Interviews | Frontline staff and residents | GREEN@ Kwai Fong, 27 October 2026 | 8 |
| Observation | Field photographs | Tai Wai, 8 November 2026 | site photos, not a behaviour count |
| Map | CSDI location layer | Hong Kong | locations, not visits |
| Prototype | Screen concept | not installed | 0 installations |
| Analysis | Thematic coding of notes | team | — |

Why this mix, as printed: the survey gives the spread; interviews give the reasons behind time and distance; photographs show what the bin looks like on site; the map shows how far the nearest point really is (Project team, 2026).

Lenses named on the poster: place (urban design), behaviour (psychology), media and AI (computer science), policy (public administration).

---

## 3. Proposed pilot targets (not results)

Every row below is a target **if a pilot is funded**. The poster marks each related measure as not measured, no values yet, or not claimed.

```mermaid
xychart-beta
    title "Proposed targets only — these bars are not observed results"
    x-axis ["Instruction time cut", "Night-slot share of visits", "Contamination cut"]
    y-axis "Percent" 0 --> 40
    bar [30, 25, 15]
```

| Target | Figure | Compared with | Status |
|---|---|---|---|
| Staff sorting-instruction time | −30% | pre-pilot baseline, per shift | Not measured |
| Night-slot share of visits | ≥25% | visits during a funded pilot | Not measured |
| Plastic contamination | −15% | pre-pilot baseline, bag inspection | No values yet |
| Hours the estate makes recycling reachable | 12 h → 24 h (09:00–21:00 on site, then screen) | current staffed window | Proposal |
| Transferable prototype | 1 → n | one unattended kit, reused estate to estate | Proposal |

Stop-rule printed on the poster: if night use stays flat, or contamination rises after guidance, the screen is not the fix and the estate should spend on staffing or hours instead (Project team, 2026).

The night screen is a concept. It is not the Tai Wai reverse vending machine, and it has not been measured against the EPD Smart Recycling Pilot (Environmental Protection Department, n.d.-c; Project team, 2026).

---

## 4. Official background (not this sample)

Use these only as programme context. They do not validate the 24% / 59% / 82% figures.

### 4.1 GREEN@COMMUNITY network (published counts)

```mermaid
xychart-beta
    title "GREEN@COMMUNITY facilities named by EPD (different facility types)"
    x-axis ["Recycling Stations", "Recycling Stores", "Recycling Spots (~)"]
    y-axis "Facilities" 0 --> 650
    bar [12, 83, 600]
```

| Published figure | Number | Unit | Do not confuse with |
|---|---:|---|---|
| Recycling Stations in operation | 12 | fixed district hubs | the 12 lobby mentions in the survey |
| Recycling Stores | 83 | stores | interview n = 8 |
| Recycling Spots | about 600 | mobile booths | survey n = 17 |
| Public collection points, with smart recycling bins | more than 800 | points | “about 600 spots” — different wording, different page |
| Smart-recycling application points | more than 800 | locations under the pilot programme | a bin count |

Sources: Environmental Protection Department (n.d.-a, n.d.-b, n.d.-c); Hong Kong Special Administrative Region Government (n.d.).

### 4.2 Hong Kong municipal solid waste, 2024 statistical year

Released by EPD on 22 December 2025 as the 2024 statistics (Environmental Protection Department, 2025; Information Services Department, 2025).

| Indicator (2024) | Figure |
|---|---|
| Municipal solid waste disposed of | 3.85 million tonnes |
| Daily disposal | 10,510 tonnes |
| Change in daily disposal vs 2023 | −3.4% (from 10,884 tonnes/day) |
| Per-capita disposal | 1.40 kg/day (−3.3% vs 1.44 kg/day in 2023) |
| Recovery rate | 34% (up from 33% in 2023) |
| Largest disposed fractions | food waste 29%, paper 23%, plastics 18% |
| Plastics disposal vs 2023 | −11.1% |

These are territory statistics. They are not outcomes of the Kwai Fong survey.

### 4.3 SDG targets named on the poster

The poster badges SDG 11.6 and SDG 12.5 only (United Nations, n.d.-a, n.d.-b).

| Badge | Target text | Indicator relevant to this poster |
|---|---|---|
| SDG 11.6 | By 2030, reduce the adverse per capita environmental impact of cities, including municipal and other waste management | 11.6.1 Proportion of municipal solid waste collected and managed in controlled facilities |
| SDG 12.5 | By 2030, substantially reduce waste generation through prevention, reduction, recycling and reuse | 12.5.1 National recycling rate, tons of material recycled |

The equity paragraph (older residents, non-Chinese-speaking households, domestic workers) is a design limit. The printed poster does not badge SDG 10.

---

## 5. Reference list (APA 7th edition)

Order is alphabetical by author, then by year. Works with no date by the same author are lettered by title (n.d.-a, n.d.-b, n.d.-c). Italics are marked with asterisks. Hanging indents are not reliable in every Markdown viewer; in Word or Google Docs, apply a 0.5-inch hanging indent to each entry.

Environmental Protection Department. (n.d.-a). *GREEN@COMMUNITY*. Hong Kong Waste Reduction Website. Retrieved November 9, 2026, from https://www.wastereduction.gov.hk/en-hk/waste-reduction-programme/green-at-community

Environmental Protection Department. (n.d.-b). *GREEN@COMMUNITY — FAQ*. Hong Kong Waste Reduction Website. Retrieved November 9, 2026, from https://www.wastereduction.gov.hk/en-hk/recycling-faq/greencommunity-faq

Environmental Protection Department. (n.d.-c). *Pilot programme on smart recycling systems*. Hong Kong Waste Reduction Website. Retrieved November 9, 2026, from https://www.wastereduction.gov.hk/en-hk/pilot-programme-smart-recycling-systems

Environmental Protection Department. (2025). *Monitoring of solid waste in Hong Kong: Waste statistics for 2024*. Hong Kong Waste Reduction Website. https://www.wastereduction.gov.hk/en-hk/resources-centre/waste-statistics

Hong Kong Special Administrative Region Government. (n.d.). *GREEN@COMMUNITY*. GovHK. Retrieved November 9, 2026, from https://www.gov.hk/en/residents/environment/waste/reduction/cgs.htm

IDEO.org. (2015). *The field guide to human-centered design* (1st ed.). https://www.designkit.org/resources/1

Information Services Department. (2025, December 22). *EPD announces waste statistics for 2024* [Press release]. Hong Kong Special Administrative Region Government. https://www.info.gov.hk/gia/general/202512/22/P2025122200311.htm

Project team. (2026). *Kwai Fong resident survey (n = 17), GREEN@ Kwai Fong interviews (n = 8), and Tai Wai site photographs* [Unpublished raw data]. ITS 2005 Section 002, Hong Kong Baptist University.

United Nations. (n.d.-a). *Goal 11: Make cities and human settlements inclusive, safe, resilient and sustainable* (Targets 11.6, 11.6.1). Department of Economic and Social Affairs. Retrieved November 9, 2026, from https://sdgs.un.org/goals/goal11

United Nations. (n.d.-b). *Goal 12: Ensure sustainable consumption and production patterns* (Targets 12.5, 12.5.1). Department of Economic and Social Affairs. Retrieved November 9, 2026, from https://sdgs.un.org/goals/goal12

United Nations. (2015). *Transforming our world: The 2030 agenda for sustainable development* (A/RES/70/1). https://sdgs.un.org/2030agenda

---

## 6. In-text citation crib (APA 7th)

| You are citing | First citation in the sentence | Parenthetical |
|---|---|---|
| The n = 17 / n = 8 dataset | Project team (2026) | (Project team, 2026) |
| 12 stations, 83 stores, about 600 spots | Environmental Protection Department (n.d.-b) | (Environmental Protection Department, n.d.-b) |
| GREEN@ programme description | Environmental Protection Department (n.d.-a) | (Environmental Protection Department, n.d.-a) |
| Smart recycling pilot, 800+ locations | Environmental Protection Department (n.d.-c) | (Environmental Protection Department, n.d.-c) |
| “More than 800 public collection points” | Hong Kong Special Administrative Region Government (n.d.) | (Hong Kong Special Administrative Region Government, n.d.) |
| 2024 disposal and recovery figures | Environmental Protection Department (2025) | (Environmental Protection Department, 2025) |
| The 22 December 2025 announcement | Information Services Department (2025) | (Information Services Department, 2025) |
| Human-centred design methods | IDEO.org (2015) | (IDEO.org, 2015) |
| SDG 11.6 | United Nations (n.d.-a) | (United Nations, n.d.-a) |
| SDG 12.5 | United Nations (n.d.-b) | (United Nations, n.d.-b) |
| Two EPD webpages at once | — | (Environmental Protection Department, n.d.-a, n.d.-b) |

Narrative example for the poster’s main claim:

> Sorting feels slow, so the normal bin wins: 14 of 17 surveyed residents (82%) said they would use an on-estate hub if the hours matched their schedule (Project team, 2026). That claim is a convenience-sample direction from Kwai Fong. It is not a measure of the GREEN@ network, which EPD describes as 12 recycling stations, 83 recycling stores and about 600 recycling spots (Environmental Protection Department, n.d.-b).

---

## 7. What is still missing

1. Group member names, so “Project team (2026)” can become a real author entry.
2. The public URL for the data pack, if the poster QR code should point at it.
3. Raw survey scores behind the 4.06 mean. The mean is reported as printed. It was not recalculated.
4. Whether “10 of 17” and “of non-users” are the same denominator in the codebook. The poster prints both. This file follows the printed fraction 10/17.
