import { Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  BookOpen,
  Check,
  Copy,
  ExternalLink,
  Lock,
  ShieldAlert,
  Unlock,
} from "lucide-react";
import {
  AUTH_LABEL,
  GROUPS,
  LEAP_INTENTS,
  TOOLS,
  leapPacket,
  type ToolGroup,
} from "@/lib/catalog";

const GATE_KEY = "hkbu-research-gate-v1";

export function ResearchGate() {
  const [group, setGroup] = useState<ToolGroup | "all">("all");
  const [armed, setArmed] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [confirmHonest, setConfirmHonest] = useState(false);
  const [confirmSelf, setConfirmSelf] = useState(false);
  const [intent, setIntent] = useState<string>(LEAP_INTENTS[0].id);
  const [question, setQuestion] = useState<string>(LEAP_INTENTS[0].prompt);
  const [copied, setCopied] = useState(false);
  const [scopeNote, setScopeNote] = useState<string | null>(null);

  useEffect(() => {
    setArmed(window.localStorage.getItem(GATE_KEY) === "armed");
    setHydrated(true);
  }, []);

  const visible = useMemo(
    () => (group === "all" ? TOOLS : TOOLS.filter((tool) => tool.group === group)),
    [group],
  );

  const packet = useMemo(() => leapPacket(intent, question), [intent, question]);

  function arm() {
    if (!confirmHonest || !confirmSelf) return;
    window.localStorage.setItem(GATE_KEY, "armed");
    setArmed(true);
    setScopeNote("Control armed for this browser. LeapSpace is still opened by you.");
  }

  function revoke() {
    window.localStorage.removeItem(GATE_KEY);
    setArmed(false);
    setConfirmHonest(false);
    setConfirmSelf(false);
    setScopeNote("Control revoked. Gated links are held again.");
  }

  function openGated(href: string, name: string) {
    if (!armed) {
      setScopeNote(`Held: ${name} needs your control before any library login path opens.`);
      return;
    }
    setScopeNote(`Opened the public guide for ${name}. Sign in only on the library page, in your browser.`);
    window.open(href, "_blank", "noopener,noreferrer");
  }

  async function copyPacket() {
    if (!armed) {
      setScopeNote("Held: the LeapSpace paste-packet stays locked until you arm control.");
      return;
    }
    await navigator.clipboard.writeText(packet);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  }

  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="border-b border-rule bg-panel">
        <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-6 sm:px-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="font-sans text-xs font-medium tracking-[0.18em] text-accent uppercase">
                HKBU Library · control gate
              </p>
              <h1 className="mt-1 font-serif text-4xl leading-none font-medium tracking-tight">
                Research Gate
              </h1>
              <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
                Public catalog of library research tools. This app does not sign in, does not store
                a password, and does not invent LeapSpace answers.
              </p>
            </div>
            <div className="flex flex-col items-start gap-2 sm:items-end">
              <nav className="flex gap-2 text-sm">
                <Link to="/" className="inline-flex min-h-11 items-center rounded-full bg-accent px-4 text-accent-ink">
                  Research gate
                </Link>
                <Link
                  to="/evidence"
                  className="inline-flex min-h-11 items-center rounded-full border border-rule px-4"
                >
                  Evidence
                </Link>
              </nav>
              <div
                className={`flex items-center gap-2 rounded-full px-3 py-2 text-sm ${
                  armed ? "bg-accent text-accent-ink" : "bg-hold-bg text-hold"
                }`}
              >
                {armed ? <Unlock className="size-4" /> : <Lock className="size-4" />}
                <span>{armed ? "Control armed" : "Auth gate locked"}</span>
              </div>
            </div>
          </div>
          <ol className="grid gap-2 sm:grid-cols-4">
            <Node
              n="1"
              title="Identify"
              body="Tool and auth type are labeled before any link."
              on
            />
            <Node
              n="2"
              title="Auth gate"
              body="No HKBU session is started from here."
              on={!armed}
            />
            <Node n="3" title="Your control" body="Two confirmations arm the gate." on={armed} />
            <Node
              n="4"
              title="Scope"
              body="Armed control opens public guides only."
              on={armed}
            />
          </ol>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)]">
        <section className="min-w-0">
          <div className="mb-3 flex items-baseline justify-between gap-3">
            <h2 className="font-serif text-2xl">Catalog</h2>
            <p className="text-xs text-muted">{visible.length} records</p>
          </div>
          <div className="mb-4 flex flex-wrap gap-2">
            {GROUPS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setGroup(item.id)}
                className={`rounded-full border px-3 py-2 text-sm ${
                  group === item.id
                    ? "border-accent bg-accent text-accent-ink"
                    : "border-rule bg-panel text-ink"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
          <ul className="flex flex-col gap-3">
            {visible.map((tool) => (
              <li key={tool.id} className="rounded-card border border-rule bg-panel p-4">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <h3 className="font-serif text-xl leading-tight">{tool.name}</h3>
                  <span
                    className={`rounded-full px-2 py-1 text-xs ${
                      tool.gated ? "bg-hold-bg text-hold" : "bg-paper text-muted"
                    }`}
                  >
                    {AUTH_LABEL[tool.auth]}
                    {tool.gated ? " · held" : " · open"}
                  </span>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-ink">{tool.use}</p>
                <p className="mt-2 text-sm leading-relaxed text-muted">{tool.access}</p>
                <button
                  type="button"
                  onClick={() => openGated(tool.href, tool.name)}
                  className="mt-3 inline-flex min-h-11 items-center gap-2 text-sm font-medium text-accent"
                >
                  <ExternalLink className="size-4" />
                  {tool.gated && !armed ? `Hold ${tool.hrefLabel}` : tool.hrefLabel}
                </button>
              </li>
            ))}
          </ul>
        </section>

        <section className="min-w-0 lg:sticky lg:top-4 lg:self-start">
          <div className="rounded-card border border-rule bg-panel p-4 sm:p-5">
            <div className="flex items-start gap-3">
              <BookOpen className="mt-1 size-5 shrink-0 text-accent" />
              <div>
                <h2 className="font-serif text-2xl">LeapSpace desk</h2>
                <p className="mt-1 text-sm leading-relaxed text-muted">
                  Elsevier tool on the library ScienceDirect subscription. Log in with your HKBU
                  email on the library path. Standard mode for a referenced answer; Deep Research
                  only if your quota allows. Funding index is about 45,000 calls.
                </p>
              </div>
            </div>

            {!armed ? (
              <fieldset className="mt-4 space-y-3 border-t border-rule pt-4">
                <legend className="flex items-center gap-2 font-sans text-sm font-medium">
                  <ShieldAlert className="size-4 text-warn" />
                  Arm control before the LeapSpace path
                </legend>
                <label className="flex items-start gap-3 text-sm leading-relaxed">
                  <input
                    type="checkbox"
                    className="mt-1 size-4 accent-accent"
                    checked={confirmHonest}
                    onChange={(event) => setConfirmHonest(event.target.checked)}
                  />
                  <span>
                    I understand this app will not authenticate as me and will not present
                    simulated LeapSpace, Scopus, or ScienceDirect results.
                  </span>
                </label>
                <label className="flex items-start gap-3 text-sm leading-relaxed">
                  <input
                    type="checkbox"
                    className="mt-1 size-4 accent-accent"
                    checked={confirmSelf}
                    onChange={(event) => setConfirmSelf(event.target.checked)}
                  />
                  <span>
                    I will sign in myself, with my own HKBU email, only on the library
                    ScienceDirect page.
                  </span>
                </label>
                <button
                  type="button"
                  disabled={!confirmHonest || !confirmSelf}
                  onClick={arm}
                  className="inline-flex min-h-11 items-center rounded-full bg-accent px-4 text-sm font-medium text-accent-ink disabled:opacity-40"
                >
                  Arm control and unlock the desk
                </button>
                {!hydrated ? null : (
                  <p className="text-xs text-muted">Control stays on this browser until you revoke it.</p>
                )}
              </fieldset>
            ) : (
              <div className="mt-4 space-y-3 border-t border-rule pt-4">
                <div className="flex flex-wrap gap-2">
                  {LEAP_INTENTS.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setIntent(item.id);
                        setQuestion(item.prompt);
                      }}
                      className={`rounded-full border px-3 py-2 text-sm ${
                        intent === item.id
                          ? "border-accent bg-accent text-accent-ink"
                          : "border-rule bg-paper"
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
                <label className="block text-sm font-medium" htmlFor="leap-q">
                  Question you will paste after you sign in
                </label>
                <textarea
                  id="leap-q"
                  value={question}
                  onChange={(event) => setQuestion(event.target.value)}
                  rows={6}
                  className="w-full rounded-card border border-rule bg-paper p-3 text-sm leading-relaxed outline-none focus:border-accent"
                />
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={copyPacket}
                    className="inline-flex min-h-11 items-center gap-2 rounded-full bg-accent px-4 text-sm font-medium text-accent-ink"
                  >
                    {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
                    {copied ? "Copied" : "Copy four-part packet"}
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      openGated(
                        "https://hkbu.libguides.com/az/databases?q=ScienceDirect",
                        "ScienceDirect A–Z",
                      )
                    }
                    className="inline-flex min-h-11 items-center gap-2 rounded-full border border-rule px-4 text-sm"
                  >
                    <ExternalLink className="size-4" />
                    ScienceDirect in A–Z
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      openGated("https://hkbu.libguides.com/leapspace/access", "LeapSpace access")
                    }
                    className="inline-flex min-h-11 items-center gap-2 rounded-full border border-rule px-4 text-sm"
                  >
                    <ExternalLink className="size-4" />
                    Access guide
                  </button>
                  <button
                    type="button"
                    onClick={revoke}
                    className="inline-flex min-h-11 items-center rounded-full px-3 text-sm text-warn"
                  >
                    Revoke control
                  </button>
                </div>
                <pre className="max-h-80 overflow-auto rounded-card border border-rule bg-paper p-3 font-sans text-xs leading-relaxed whitespace-pre-wrap">
                  {packet}
                </pre>
              </div>
            )}

            {scopeNote ? (
              <p className="mt-4 rounded-card bg-hold-bg px-3 py-2 text-sm text-hold" role="status">
                {scopeNote}
              </p>
            ) : null}

            <p className="mt-4 text-xs leading-relaxed text-muted">
              Sources checked as public pages: LeapSpace guide (22 Apr 2026), library subscription
              note (access via ScienceDirect), Consensus guide (31 Aug 2026), OpenAthens e-resources
              guide, generative-AI tool list, and the research-support service page. The library
              does not support the open tools on that list, and licensed full text must not be
              uploaded to them.
            </p>
          </div>
        </section>
      </main>
    </div>
  );
}

function Node({
  n,
  title,
  body,
  on,
}: {
  n: string;
  title: string;
  body: string;
  on: boolean;
}) {
  return (
    <li className={`rounded-card border px-3 py-3 ${on ? "border-accent bg-paper" : "border-rule bg-paper"}`}>
      <p className="text-xs tracking-wide text-muted uppercase">Node {n}</p>
      <p className="font-serif text-lg leading-tight">{title}</p>
      <p className="mt-1 text-xs leading-relaxed text-muted">{body}</p>
    </li>
  );
}
