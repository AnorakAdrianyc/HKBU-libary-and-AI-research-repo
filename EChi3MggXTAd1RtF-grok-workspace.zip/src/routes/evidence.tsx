import { createFileRoute, Link } from "@tanstack/react-router";
import { CHANNELS, CONTRAST, NETWORK, PACK, SPINE, STATIONS } from "@/lib/evidence";

export const Route = createFileRoute("/evidence")({ component: EvidenceBoard });

const LON0 = 113.82;
const LON1 = 114.42;
const LAT0 = 22.2;
const LAT1 = 22.56;

function EvidenceBoard() {
  const donut = `conic-gradient(var(--color-accent) 0 ${NETWORK[0].share * 100}%, var(--color-hold) ${NETWORK[0].share * 100}% ${(NETWORK[0].share + NETWORK[1].share) * 100}%, var(--color-ink) ${(NETWORK[0].share + NETWORK[1].share) * 100}% 100%)`;

  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="border-b border-rule bg-panel">
        <div className="mx-auto flex max-w-6xl flex-wrap items-end justify-between gap-4 px-4 py-6 sm:px-6">
          <div>
            <p className="text-xs font-medium tracking-[0.18em] text-accent uppercase">
              Viz pack · not a live feed
            </p>
            <h1 className="mt-1 font-serif text-4xl leading-none">Evidence board</h1>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
              Counts from the ITS2005 sheets, retrieved {PACK.retrieved}. Location is not behaviour.
              800+ points and 159 bin sets use different units and are not added.
            </p>
          </div>
          <nav className="flex gap-2 text-sm">
            <Link to="/" className="inline-flex min-h-11 items-center rounded-full border border-rule px-4">
              Research gate
            </Link>
            <Link
              to="/evidence"
              className="inline-flex min-h-11 items-center rounded-full bg-accent px-4 text-accent-ink"
            >
              Evidence
            </Link>
          </nav>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-4 px-4 py-6 sm:px-6 lg:grid-cols-2">
        <section className="rounded-card border border-rule bg-panel p-4">
          <h2 className="font-serif text-2xl">Network composition</h2>
          <p className="mt-1 text-xs text-muted">
            Observed · EPD GREEN@COMMUNITY page · as of {PACK.asOf}. Shares use 12 + 83 + ~600.
            The 600 is printed as approximate.
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-6">
            <div
              className="grid size-36 place-items-center rounded-full"
              style={{ background: donut }}
              role="img"
              aria-label="Donut of 12 stations, 83 stores, and about 600 spots"
            >
              <div className="grid size-20 place-items-center rounded-full bg-panel text-center text-xs">
                Where
                <br />
                only
              </div>
            </div>
            <ul className="space-y-2 text-sm">
              {NETWORK.map((row) => (
                <li key={row.layer}>
                  <span className="font-medium">{row.count}</span> {row.layer}
                  <span className="text-muted"> · {(row.share * 100).toFixed(1)}%</span>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="rounded-card border border-rule bg-panel p-4">
          <h2 className="font-serif text-2xl">Do not add these</h2>
          <p className="mt-1 text-xs text-muted">
            Observed on two sources and two dates. Interpretation: they describe different objects.
          </p>
          <ul className="mt-4 space-y-3">
            {CONTRAST.map((row) => (
              <li key={row.id} className="rounded-card border border-rule bg-paper p-3">
                <p className="font-serif text-3xl leading-none">{row.value}</p>
                <p className="mt-1 text-sm">{row.unit}</p>
                <p className="text-xs text-muted">
                  {row.label}. {row.source}. As of {row.asOf}.
                </p>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-sm text-warn">Unknown if either number changed after its as-of date.</p>
        </section>

        <section className="rounded-card border border-rule bg-panel p-4 lg:col-span-2">
          <h2 className="font-serif text-2xl">Twelve stations</h2>
          <p className="mt-1 text-xs text-muted">
            Observed · CSDI polygons · snapshot {PACK.asOf}. This plot is positions only. It is not a
            choropleth and not a visit map. Missing sites are omitted, not drawn as zero.
          </p>
          <div className="relative mt-4 h-72 rounded-card border border-rule bg-paper">
            {STATIONS.map((station) => {
              const left = ((station.lon - LON0) / (LON1 - LON0)) * 100;
              const top = ((LAT1 - station.lat) / (LAT1 - LAT0)) * 100;
              return (
                <span
                  key={station.name}
                  title={`${station.name} · ${station.address}`}
                  className="absolute size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent"
                  style={{ left: `${left}%`, top: `${top}%` }}
                />
              );
            })}
          </div>
          <ul className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
            {STATIONS.map((station) => (
              <li key={station.name}>
                <span className="font-medium">{station.name}</span>
                <span className="text-muted"> · {station.zh}</span>
                <br />
                <span className="text-muted">{station.address}</span>
              </li>
            ))}
          </ul>
        </section>

        <section className="rounded-card border border-rule bg-panel p-4">
          <h2 className="font-serif text-2xl">Access-first order</h2>
          <p className="mt-1 text-xs text-muted">
            Hypothesis rank from the project spine. Not a measured effect.
          </p>
          <ol className="mt-4 space-y-2">
            {SPINE.map((row) => (
              <li key={row.rank} className="flex items-center gap-3 text-sm">
                <span className="w-6 font-medium text-accent">{row.rank}</span>
                <span
                  className="h-2 rounded-full bg-accent"
                  style={{ width: `${110 - row.rank * 16}px` }}
                />
                <span>
                  {row.element}
                  <span className="text-muted"> · {row.status}</span>
                </span>
              </li>
            ))}
          </ol>
        </section>

        <section className="rounded-card border border-rule bg-panel p-4">
          <h2 className="font-serif text-2xl">Channels</h2>
          <p className="mt-1 text-xs text-muted">
            Every row is unmeasured. No traffic adapter is connected, so none of these are attention
            or demand.
          </p>
          <ul className="mt-4 space-y-2 text-sm">
            {CHANNELS.map((row) => (
              <li key={row.channel} className="flex justify-between gap-3 border-b border-rule py-2">
                <span>
                  {row.channel}
                  <span className="block text-xs text-muted">{row.audience}</span>
                </span>
                <span className="text-hold">{row.status}</span>
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
}
