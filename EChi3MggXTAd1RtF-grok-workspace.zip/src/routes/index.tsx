import { createFileRoute } from "@tanstack/react-router";
import { ResearchGate } from "@/components/research-gate";

export const Route = createFileRoute("/")({ component: ResearchGate });
