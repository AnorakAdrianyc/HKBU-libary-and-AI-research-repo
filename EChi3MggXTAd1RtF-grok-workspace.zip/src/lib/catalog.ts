export type AuthKind =
  | "open"
  | "hkbu-email"
  | "openathens"
  | "library-proxy"
  | "ssoid"
  | "campus-license";

export type ToolGroup =
  | "library-ai"
  | "research-support"
  | "open-ai"
  | "data-quant";

export type ResearchTool = {
  id: string;
  name: string;
  group: ToolGroup;
  auth: AuthKind;
  gated: boolean;
  use: string;
  access: string;
  href: string;
  hrefLabel: string;
};

export const GROUPS: { id: ToolGroup | "all"; label: string }[] = [
  { id: "all", label: "All" },
  { id: "library-ai", label: "Library AI" },
  { id: "research-support", label: "Research support" },
  { id: "open-ai", label: "Open tools" },
  { id: "data-quant", label: "Data & quant" },
];

export const AUTH_LABEL: Record<AuthKind, string> = {
  open: "Open",
  "hkbu-email": "HKBU email",
  openathens: "OpenAthens",
  "library-proxy": "Library proxy",
  ssoid: "HKBU SSOid",
  "campus-license": "Campus license",
};

/** Public catalog only. No live session, no spoofed results. */
export const TOOLS: ResearchTool[] = [
  {
    id: "leapspace",
    name: "LeapSpace",
    group: "library-ai",
    auth: "hkbu-email",
    gated: true,
    use: "Full-text synthesis, collaborator discovery, and ~45,000 funding records. Replaces Scopus AI. Elsevier; Scopus abstracts plus ScienceDirect and partner full text (Emerald, IOP, NEJM, Sage).",
    access:
      "Sign in with your HKBU email. Reach it through the library ScienceDirect record in the A–Z list, not a guessed product URL.",
    href: "https://hkbu.libguides.com/leapspace/access",
    hrefLabel: "Access & security guide",
  },
  {
    id: "consensus",
    name: "Consensus",
    group: "library-ai",
    auth: "hkbu-email",
    gated: true,
    use: "Evidence-backed answers over ~250 million papers (Semantic Scholar, OpenAlex, publisher full text where marked). Premium (unlimited Pro, Deep search quota, snapshots, table view) is the library tier.",
    access:
      "Create an account with your HKBU email, confirm the code, and set the institution to Hong Kong Baptist University.",
    href: "https://hkbu.libguides.com/consensus",
    hrefLabel: "Consensus guide",
  },
  {
    id: "scite",
    name: "scite",
    group: "library-ai",
    auth: "hkbu-email",
    gated: true,
    use: "Smart citations: supporting, contrasting, or mentioning. Useful when a claim needs dispute context rather than a summary.",
    access: "Institutional access is listed on the library AI comparison. Confirm the current path in the guide before use.",
    href: "https://hkbu.libguides.com/generative-ai",
    hrefLabel: "Generative AI guide",
  },
  {
    id: "endnote",
    name: "EndNote",
    group: "research-support",
    auth: "campus-license",
    gated: true,
    use: "Site-licensed reference manager. Export from Consensus as RIS, CSV, or bibliography and keep the claim ledger citeable.",
    access: "Eligible faculty, staff, and students via the library software path.",
    href: "https://library.hkbu.edu.hk/services/research-support/",
    hrefLabel: "Research support",
  },
  {
    id: "openathens",
    name: "OpenAthens",
    group: "research-support",
    auth: "openathens",
    gated: true,
    use: "Single sign-on for library e-resources, on and off campus. One session, up to about eight hours.",
    access:
      "Students, faculty, and staff: HKBU email and password. Some borrower classes use a library-card barcode and must use a library PC.",
    href: "https://hkbu.libguides.com/e-resources-access",
    hrefLabel: "E-resources access",
  },
  {
    id: "libkey",
    name: "LibKey Nomad",
    group: "research-support",
    auth: "open",
    gated: false,
    use: "Browser extension that spots HKBU-subscribed articles while you browse and routes you to the library copy.",
    access: "Install the extension, then authenticate only when the library prompts you.",
    href: "https://hkbu.libguides.com/generative-ai",
    hrefLabel: "Library guides",
  },
  {
    id: "rds",
    name: "Research Data Services",
    group: "research-support",
    auth: "campus-license",
    gated: true,
    use: "Analytics, visualisation, research data management, and data-source access. Home for the CSDI station layer and metric sheets.",
    access: "Campus tools (including GIS licenses) stay behind library or software-portal credentials.",
    href: "https://library.hkbu.edu.hk/services/research-support/",
    hrefLabel: "Research support",
  },
  {
    id: "integrity",
    name: "Academic integrity",
    group: "research-support",
    auth: "ssoid",
    gated: true,
    use: "Turnitin for coursework and iThenticate for staff manuscripts. The library advises against unreliable AI-text detectors.",
    access: "University platforms. Do not treat detector scores as findings.",
    href: "https://library.hkbu.edu.hk/services/research-support/",
    hrefLabel: "Research support",
  },
  {
    id: "visibility",
    name: "Output visibility & impact",
    group: "research-support",
    auth: "open",
    gated: false,
    use: "Open access, copyright, and research-impact advice before a poster or proposal leaves the course folder.",
    access: "Public service page. Librarians handle the gated follow-up.",
    href: "https://library.hkbu.edu.hk/services/research-support/",
    hrefLabel: "Research support",
  },
  {
    id: "digital-scholarship",
    name: "Digital scholarship",
    group: "research-support",
    auth: "open",
    gated: false,
    use: "Faculty collaborations and a digital scholarship grant for research tools. Relevant if the station map becomes a living lab artifact.",
    access: "Start from the public service description; applications are a separate university process.",
    href: "https://library.hkbu.edu.hk/services/research-support/",
    hrefLabel: "Research support",
  },
  {
    id: "genai-platform",
    name: "HKBU GenAI Platform",
    group: "open-ai",
    auth: "ssoid",
    gated: true,
    use: "Campus chatbot (ChatGPT via SSOid). Appropriate for drafts that must stay inside the university tenant — not for uploading licensed articles.",
    access: "https://genai.hkbu.edu.hk with HKBU SSOid.",
    href: "https://genai.hkbu.edu.hk",
    hrefLabel: "GenAI platform",
  },
  {
    id: "elicit",
    name: "Elicit",
    group: "open-ai",
    auth: "open",
    gated: false,
    use: "Structured extraction of facts, events, and entities. The library lists it but does not support it.",
    access: "Freemium account on elicit.com. Do not upload licensed full text.",
    href: "https://elicit.com",
    hrefLabel: "Elicit",
  },
  {
    id: "rabbit",
    name: "Research Rabbit",
    group: "open-ai",
    auth: "open",
    gated: false,
    use: "Visual exploration of related papers and thematic clusters.",
    access: "Open account. Seed it with papers you already have rights to cite.",
    href: "https://www.researchrabbit.ai",
    hrefLabel: "Research Rabbit",
  },
  {
    id: "connected",
    name: "Connected Papers",
    group: "open-ai",
    auth: "open",
    gated: false,
    use: "Co-citation maps when a LeapSpace or Consensus hit needs its neighbourhood.",
    access: "Open, with usage limits.",
    href: "https://www.connectedpapers.com",
    hrefLabel: "Connected Papers",
  },
  {
    id: "perplexity",
    name: "Perplexity",
    group: "open-ai",
    auth: "open",
    gated: false,
    use: "Current policy and news with citations. Not a substitute for Scopus full text.",
    access: "Open or Pro. Keep regulatory claims marked for verification.",
    href: "https://www.perplexity.ai",
    hrefLabel: "Perplexity",
  },
  {
    id: "gamma",
    name: "Gamma",
    group: "open-ai",
    auth: "open",
    gated: false,
    use: "Slide and one-page drafts. The course still wants one editable Canva page; Gamma is a sketch tool only.",
    access: "Independent account. Free tier exists.",
    href: "https://gamma.app",
    hrefLabel: "Gamma",
  },
  {
    id: "data-repo",
    name: "Data Repository @ HKBU",
    group: "data-quant",
    auth: "ssoid",
    gated: true,
    use: "Citable deposit for datasets you are allowed to share. Not a place for quarantined survey percentages.",
    access: "HKBU login on the digital library.",
    href: "https://digital.lib.hkbu.edu.hk",
    hrefLabel: "Digital library",
  },
];

export const LEAP_INTENTS = [
  {
    id: "synthesis",
    label: "Literature synthesis",
    prompt:
      "Synthesise peer-reviewed work on municipal recycling access barriers versus digital guidance in dense Asian cities. Separate operational capacity (opening hours, estate access, collection schedules) from awareness interventions. Flag studies that measure contamination or diversion, and studies that only measure knowledge or intention.",
  },
  {
    id: "article",
    label: "Full-text read",
    prompt:
      "When I paste a DOI I already have rights to open, extract: setting, intervention, outcome measures, and whether the authors claim a staff-workload reduction. Quote only what the full text supports. Mark abstract-only claims.",
  },
  {
    id: "people",
    label: "Collaborators",
    prompt:
      "Identify active researchers on living labs, circular-economy incubation, or Hong Kong waste infrastructure. Return names, affiliation, and why the work is adjacent — not a claim that they are partners.",
  },
  {
    id: "funding",
    label: "Funding",
    prompt:
      "List open funding calls relevant to circular economy, waste valorisation, or community recycling pilots that a student team could not lead alone but a university living lab might. Include funder, deadline if shown, and eligibility limits.",
  },
] as const;

export function leapPacket(intentId: string, question: string) {
  const intent = LEAP_INTENTS.find((item) => item.id === intentId) ?? LEAP_INTENTS[0];
  const q = question.trim() || intent.prompt;
  return [
    "1. Recommended HKBU tool",
    "LeapSpace (Elsevier), reached through the HKBU Library ScienceDirect subscription. Consensus is the lighter alternative for a consensus meter; scite if you need supporting versus disputing citations. This packet does not call any of them.",
    "",
    "2. Actionable execution step",
    "a. Open the library A–Z databases list and search ScienceDirect.",
    "b. Authenticate yourself with your HKBU email when OpenAthens or the publisher asks. This app never sees that password.",
    "c. Open LeapSpace from inside that subscription.",
    "d. Paste the question below. Prefer Deep Research only if your library tier still has quota; otherwise use the standard mode.",
    "e. Bring citations back into EndNote. Do not upload licensed PDFs into a third-party chatbot.",
    "",
    "Question to paste:",
    q,
    "",
    "Spine constraint to keep in the prompt:",
    "Access and schedule first. Any AI guidance is an untested edge demo, not a measured staff-load cut. Maps show where facilities are, not behaviour. Application points are not bin sets.",
    "",
    "3. Analytical synthesis / draft",
    "NOT a LeapSpace result. A working frame you can discard if the sources disagree:",
    "Estate access and published schedules are the operational constraint. A website or kiosk assistant can only add after-hours guidance if the building is actually open and the material is collected. Awareness aimed at Gen Z can raise visits without lowering contamination if the reverse-logistics step is missing. Treat living-lab and digital-entertainment channels as future design, and label evaluation metrics as a plan.",
    "",
    "4. Institutional compliance / auth note",
    "Credential: your HKBU email on the library ScienceDirect path (OpenAthens session, about eight hours). Do not paste licensed full text into Elicit, Perplexity, Gamma, or the public GenAI tools. Library guidance: user queries on LeapSpace are not used to train public models, but licensed content still must not be uploaded to unauthorised third parties. This console did not authenticate and did not retrieve paywalled text.",
  ].join("\n");
}
