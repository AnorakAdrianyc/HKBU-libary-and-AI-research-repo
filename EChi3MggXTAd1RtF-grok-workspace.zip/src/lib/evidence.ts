/** User-supplied viz pack, read 9 Nov 2026. Not a live adapter. */

export const PACK = {
  retrieved: "2026-11-09",
  asOf: "2026-11-08",
  source: "ITS2005 viz pack (Drive sheets 01–06)",
} as const;

export const NETWORK = [
  { layer: "Recycling stations", count: 12, share: 0.0173, tag: "Observed" },
  { layer: "Recycling stores", count: 83, share: 0.1194, tag: "Observed" },
  { layer: "Recycling spots (approx.)", count: 600, share: 0.8633, tag: "Observed" },
] as const;

export const CONTRAST = [
  {
    id: "points",
    value: 800,
    unit: "application / collection points",
    label: "800+ as printed (lower bound)",
    source: "EPD Smart Recycling Pilot page",
    asOf: "2026-11-08",
    tag: "Observed",
  },
  {
    id: "sets",
    value: 159,
    unit: "smart recycling bin sets",
    label: "As at end of June 2025",
    source: "LCQ9, 16 July 2025",
    asOf: "2025-06-30",
    tag: "Observed",
  },
] as const;

export const STATIONS = [
  { name: "GREEN@EASTERN", zh: "綠在東區", address: "30 Oi Shun Road, Shau Kei Wan", lon: 114.22428, lat: 22.281207 },
  { name: "GREEN@ISLANDS", zh: "綠在離島", address: "1 Chung Mun Road, Tung Chung", lon: 113.932059, lat: 22.278285 },
  { name: "GREEN@KWAI TSING", zh: "綠在葵青", address: "12 Tam Kon Shan Road, Tsing Yi", lon: 114.096579, lat: 22.361156 },
  { name: "GREEN@SHAM SHUI PO", zh: "綠在深水埗", address: "339 Tung Chau Street, Sham Shui Po", lon: 114.156351, lat: 22.329108 },
  { name: "GREEN@SHA TIN", zh: "綠在沙田", address: "10 On Ping Street, Shek Mun", lon: 114.208796, lat: 22.392378 },
  { name: "GREEN@TAI PO", zh: "綠在大埔", address: "25 Dai Wah Street, Tai Po", lon: 114.179993, lat: 22.458301 },
  { name: "GREEN@WAN CHAI", zh: "綠在灣仔", address: "6 Wan Shing Street, Wan Chai", lon: 114.179148, lat: 22.28212 },
  { name: "GREEN@TUEN MUN", zh: "綠在屯門", address: "9 Tuen Yee Street, Tuen Mun", lon: 113.968301, lat: 22.383172 },
  { name: "GREEN@KWUN TONG", zh: "綠在觀塘", address: "27 Sheung Yee Road, Kowloon Bay", lon: 114.207439, lat: 22.319936 },
  { name: "GREEN@YUEN LONG", zh: "綠在元朗", address: "65 Tin Wah Road, Tin Shui Wai", lon: 114.009052, lat: 22.462537 },
  { name: "GREEN@SAI KUNG", zh: "綠在西貢", address: "3 Po Lam Lane, Tseung Kwan O", lon: 114.250951, lat: 22.325688 },
  { name: "GREEN@WONG TAI SIN", zh: "綠在黃大仙", address: "Po Kong Village Road, Wong Tai Sin", lon: 114.203808, lat: 22.346258 },
] as const;

export const SPINE = [
  { rank: 1, element: "Estate access and schedule", status: "Primary" },
  { rank: 2, element: "Building-level convenience", status: "Primary" },
  { rank: 3, element: "Website AI guidance", status: "Demo edge only" },
  { rank: 4, element: "Gen Z+ digital entertainment", status: "Demo, untested" },
  { rank: 5, element: "University living-lab seats", status: "Future" },
] as const;

export const CHANNELS = [
  { channel: "Website AI", audience: "After-hours askers", status: "Demo", measured: false },
  { channel: "Gen Z+ digital entertainment", audience: "Gen Z and above", status: "Demo, untested", measured: false },
  { channel: "University living-lab hubs", audience: "Incubators and stakeholders", status: "Future", measured: false },
  { channel: "Social media", audience: "Public", status: "Demo", measured: false },
  { channel: "Events / exhibition", audience: "Public and trade", status: "Demo", measured: false },
  { channel: "HKTDC / trade", audience: "Industry", status: "Demo", measured: false },
] as const;
