//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-I3aMajj8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BXOu0vzZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BXOu0vzZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Ca2q2VYV.js"]
	}
} });
//#endregion
export { tsrStartManifest };
