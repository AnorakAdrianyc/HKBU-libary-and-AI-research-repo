import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ExternalLink, c as BookOpen, i as LockOpen, n as ShieldAlert, o as Copy, r as Lock, s as Check } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BEg_mapZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GROUPS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "library-ai",
		label: "Library AI"
	},
	{
		id: "research-support",
		label: "Research support"
	},
	{
		id: "open-ai",
		label: "Open tools"
	},
	{
		id: "data-quant",
		label: "Data & quant"
	}
];
var AUTH_LABEL = {
	open: "Open",
	"hkbu-email": "HKBU email",
	openathens: "OpenAthens",
	"library-proxy": "Library proxy",
	ssoid: "HKBU SSOid",
	"campus-license": "Campus license"
};
/** Public catalog only. No live session, no spoofed results. */
var TOOLS = [
	{
		id: "leapspace",
		name: "LeapSpace",
		group: "library-ai",
		auth: "hkbu-email",
		gated: true,
		use: "Full-text synthesis, collaborator discovery, and ~45,000 funding records. Replaces Scopus AI. Elsevier; Scopus abstracts plus ScienceDirect and partner full text (Emerald, IOP, NEJM, Sage).",
		access: "Sign in with your HKBU email. Reach it through the library ScienceDirect record in the A–Z list, not a guessed product URL.",
		href: "https://hkbu.libguides.com/leapspace/access",
		hrefLabel: "Access & security guide"
	},
	{
		id: "consensus",
		name: "Consensus",
		group: "library-ai",
		auth: "hkbu-email",
		gated: true,
		use: "Evidence-backed answers over ~250 million papers (Semantic Scholar, OpenAlex, publisher full text where marked). Premium (unlimited Pro, Deep search quota, snapshots, table view) is the library tier.",
		access: "Create an account with your HKBU email, confirm the code, and set the institution to Hong Kong Baptist University.",
		href: "https://hkbu.libguides.com/consensus",
		hrefLabel: "Consensus guide"
	},
	{
		id: "scite",
		name: "scite",
		group: "library-ai",
		auth: "hkbu-email",
		gated: true,
		use: "Smart citations: supporting, contrasting, or mentioning. Useful when a claim needs dispute context rather than a summary.",
		access: "Institutional access is listed on the library AI comparison. Confirm the current path in the guide before use.",
		href: "https://hkbu.libguides.com/generative-ai",
		hrefLabel: "Generative AI guide"
	},
	{
		id: "endnote",
		name: "EndNote",
		group: "research-support",
		auth: "campus-license",
		gated: true,
		use: "Site-licensed reference manager. Export from Consensus as RIS, CSV, or bibliography and keep the claim ledger citeable.",
		access: "Eligible faculty, staff, and students via the library software path.",
		href: "https://library.hkbu.edu.hk/services/research-support/",
		hrefLabel: "Research support"
	},
	{
		id: "openathens",
		name: "OpenAthens",
		group: "research-support",
		auth: "openathens",
		gated: true,
		use: "Single sign-on for library e-resources, on and off campus. One session, up to about eight hours.",
		access: "Students, faculty, and staff: HKBU email and password. Some borrower classes use a library-card barcode and must use a library PC.",
		href: "https://hkbu.libguides.com/e-resources-access",
		hrefLabel: "E-resources access"
	},
	{
		id: "libkey",
		name: "LibKey Nomad",
		group: "research-support",
		auth: "open",
		gated: false,
		use: "Browser extension that spots HKBU-subscribed articles while you browse and routes you to the library copy.",
		access: "Install the extension, then authenticate only when the library prompts you.",
		href: "https://hkbu.libguides.com/generative-ai",
		hrefLabel: "Library guides"
	},
	{
		id: "rds",
		name: "Research Data Services",
		group: "research-support",
		auth: "campus-license",
		gated: true,
		use: "Analytics, visualisation, research data management, and data-source access. Home for the CSDI station layer and metric sheets.",
		access: "Campus tools (including GIS licenses) stay behind library or software-portal credentials.",
		href: "https://library.hkbu.edu.hk/services/research-support/",
		hrefLabel: "Research support"
	},
	{
		id: "integrity",
		name: "Academic integrity",
		group: "research-support",
		auth: "ssoid",
		gated: true,
		use: "Turnitin for coursework and iThenticate for staff manuscripts. The library advises against unreliable AI-text detectors.",
		access: "University platforms. Do not treat detector scores as findings.",
		href: "https://library.hkbu.edu.hk/services/research-support/",
		hrefLabel: "Research support"
	},
	{
		id: "visibility",
		name: "Output visibility & impact",
		group: "research-support",
		auth: "open",
		gated: false,
		use: "Open access, copyright, and research-impact advice before a poster or proposal leaves the course folder.",
		access: "Public service page. Librarians handle the gated follow-up.",
		href: "https://library.hkbu.edu.hk/services/research-support/",
		hrefLabel: "Research support"
	},
	{
		id: "digital-scholarship",
		name: "Digital scholarship",
		group: "research-support",
		auth: "open",
		gated: false,
		use: "Faculty collaborations and a digital scholarship grant for research tools. Relevant if the station map becomes a living lab artifact.",
		access: "Start from the public service description; applications are a separate university process.",
		href: "https://library.hkbu.edu.hk/services/research-support/",
		hrefLabel: "Research support"
	},
	{
		id: "genai-platform",
		name: "HKBU GenAI Platform",
		group: "open-ai",
		auth: "ssoid",
		gated: true,
		use: "Campus chatbot (ChatGPT via SSOid). Appropriate for drafts that must stay inside the university tenant — not for uploading licensed articles.",
		access: "https://genai.hkbu.edu.hk with HKBU SSOid.",
		href: "https://genai.hkbu.edu.hk",
		hrefLabel: "GenAI platform"
	},
	{
		id: "elicit",
		name: "Elicit",
		group: "open-ai",
		auth: "open",
		gated: false,
		use: "Structured extraction of facts, events, and entities. The library lists it but does not support it.",
		access: "Freemium account on elicit.com. Do not upload licensed full text.",
		href: "https://elicit.com",
		hrefLabel: "Elicit"
	},
	{
		id: "rabbit",
		name: "Research Rabbit",
		group: "open-ai",
		auth: "open",
		gated: false,
		use: "Visual exploration of related papers and thematic clusters.",
		access: "Open account. Seed it with papers you already have rights to cite.",
		href: "https://www.researchrabbit.ai",
		hrefLabel: "Research Rabbit"
	},
	{
		id: "connected",
		name: "Connected Papers",
		group: "open-ai",
		auth: "open",
		gated: false,
		use: "Co-citation maps when a LeapSpace or Consensus hit needs its neighbourhood.",
		access: "Open, with usage limits.",
		href: "https://www.connectedpapers.com",
		hrefLabel: "Connected Papers"
	},
	{
		id: "perplexity",
		name: "Perplexity",
		group: "open-ai",
		auth: "open",
		gated: false,
		use: "Current policy and news with citations. Not a substitute for Scopus full text.",
		access: "Open or Pro. Keep regulatory claims marked for verification.",
		href: "https://www.perplexity.ai",
		hrefLabel: "Perplexity"
	},
	{
		id: "gamma",
		name: "Gamma",
		group: "open-ai",
		auth: "open",
		gated: false,
		use: "Slide and one-page drafts. The course still wants one editable Canva page; Gamma is a sketch tool only.",
		access: "Independent account. Free tier exists.",
		href: "https://gamma.app",
		hrefLabel: "Gamma"
	},
	{
		id: "data-repo",
		name: "Data Repository @ HKBU",
		group: "data-quant",
		auth: "ssoid",
		gated: true,
		use: "Citable deposit for datasets you are allowed to share. Not a place for quarantined survey percentages.",
		access: "HKBU login on the digital library.",
		href: "https://digital.lib.hkbu.edu.hk",
		hrefLabel: "Digital library"
	}
];
var LEAP_INTENTS = [
	{
		id: "synthesis",
		label: "Literature synthesis",
		prompt: "Synthesise peer-reviewed work on municipal recycling access barriers versus digital guidance in dense Asian cities. Separate operational capacity (opening hours, estate access, collection schedules) from awareness interventions. Flag studies that measure contamination or diversion, and studies that only measure knowledge or intention."
	},
	{
		id: "article",
		label: "Full-text read",
		prompt: "When I paste a DOI I already have rights to open, extract: setting, intervention, outcome measures, and whether the authors claim a staff-workload reduction. Quote only what the full text supports. Mark abstract-only claims."
	},
	{
		id: "people",
		label: "Collaborators",
		prompt: "Identify active researchers on living labs, circular-economy incubation, or Hong Kong waste infrastructure. Return names, affiliation, and why the work is adjacent — not a claim that they are partners."
	},
	{
		id: "funding",
		label: "Funding",
		prompt: "List open funding calls relevant to circular economy, waste valorisation, or community recycling pilots that a student team could not lead alone but a university living lab might. Include funder, deadline if shown, and eligibility limits."
	}
];
function leapPacket(intentId, question) {
	const intent = LEAP_INTENTS.find((item) => item.id === intentId) ?? LEAP_INTENTS[0];
	return [
		"1. Recommended HKBU tool",
		"LeapSpace (Elsevier), reached through the HKBU Library ScienceDirect subscription. Consensus is the lighter alternative for a consensus meter; scite if you need supporting versus disputing citations. This packet does not call any of them.",
		"",
		"2. Actionable execution step",
		"a. Open the library A–Z databases list and search ScienceDirect.",
		"b. Authenticate yourself with your HKBU email when OpenAthens or the publisher asks. This app never sees that password.",
		"c. Open LeapSpace from inside that subscription.",
		"d. Paste the question below. Prefer Deep Research only if your library tier still has quota; otherwise use the standard mode.",
		"e. Bring citations back into EndNote. Do not upload licensed PDFs into a third-party chatbot.",
		"",
		"Question to paste:",
		question.trim() || intent.prompt,
		"",
		"Spine constraint to keep in the prompt:",
		"Access and schedule first. Any AI guidance is an untested edge demo, not a measured staff-load cut. Maps show where facilities are, not behaviour. Application points are not bin sets.",
		"",
		"3. Analytical synthesis / draft",
		"NOT a LeapSpace result. A working frame you can discard if the sources disagree:",
		"Estate access and published schedules are the operational constraint. A website or kiosk assistant can only add after-hours guidance if the building is actually open and the material is collected. Awareness aimed at Gen Z can raise visits without lowering contamination if the reverse-logistics step is missing. Treat living-lab and digital-entertainment channels as future design, and label evaluation metrics as a plan.",
		"",
		"4. Institutional compliance / auth note",
		"Credential: your HKBU email on the library ScienceDirect path (OpenAthens session, about eight hours). Do not paste licensed full text into Elicit, Perplexity, Gamma, or the public GenAI tools. Library guidance: user queries on LeapSpace are not used to train public models, but licensed content still must not be uploaded to unauthorised third parties. This console did not authenticate and did not retrieve paywalled text."
	].join("\n");
}
var GATE_KEY = "hkbu-research-gate-v1";
function ResearchGate() {
	const [group, setGroup] = (0, import_react.useState)("all");
	const [armed, setArmed] = (0, import_react.useState)(false);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [confirmHonest, setConfirmHonest] = (0, import_react.useState)(false);
	const [confirmSelf, setConfirmSelf] = (0, import_react.useState)(false);
	const [intent, setIntent] = (0, import_react.useState)(LEAP_INTENTS[0].id);
	const [question, setQuestion] = (0, import_react.useState)(LEAP_INTENTS[0].prompt);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [scopeNote, setScopeNote] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setArmed(window.localStorage.getItem(GATE_KEY) === "armed");
		setHydrated(true);
	}, []);
	const visible = (0, import_react.useMemo)(() => group === "all" ? TOOLS : TOOLS.filter((tool) => tool.group === group), [group]);
	const packet = (0, import_react.useMemo)(() => leapPacket(intent, question), [intent, question]);
	function arm() {
		if (!confirmHonest || !confirmSelf) return;
		window.localStorage.setItem(GATE_KEY, "armed");
		setArmed(true);
		setScopeNote("Control armed for this browser. LeapSpace is still opened by you.");
	}
	function revoke() {
		window.localStorage.removeItem(GATE_KEY);
		setArmed(false);
		setConfirmHonest(false);
		setConfirmSelf(false);
		setScopeNote("Control revoked. Gated links are held again.");
	}
	function openGated(href, name) {
		if (!armed) {
			setScopeNote(`Held: ${name} needs your control before any library login path opens.`);
			return;
		}
		setScopeNote(`Opened the public guide for ${name}. Sign in only on the library page, in your browser.`);
		window.open(href, "_blank", "noopener,noreferrer");
	}
	async function copyPacket() {
		if (!armed) {
			setScopeNote("Held: the LeapSpace paste-packet stays locked until you arm control.");
			return;
		}
		await navigator.clipboard.writeText(packet);
		setCopied(true);
		window.setTimeout(() => setCopied(false), 1600);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-rule bg-panel",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-6 px-4 py-6 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-sans text-xs font-medium tracking-[0.18em] text-accent uppercase",
							children: "HKBU Library · control gate"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 font-serif text-4xl leading-none font-medium tracking-tight",
							children: "Research Gate"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-sm leading-relaxed text-muted",
							children: "Public catalog of library research tools. This app does not sign in, does not store a password, and does not invent LeapSpace answers."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `flex items-center gap-2 rounded-full px-3 py-2 text-sm ${armed ? "bg-accent text-accent-ink" : "bg-hold-bg text-hold"}`,
						children: [armed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: armed ? "Control armed" : "Auth gate locked" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "grid gap-2 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
							n: "1",
							title: "Identify",
							body: "Tool and auth type are labeled before any link.",
							on: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
							n: "2",
							title: "Auth gate",
							body: "No HKBU session is started from here.",
							on: !armed
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
							n: "3",
							title: "Your control",
							body: "Two confirmations arm the gate.",
							on: armed
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
							n: "4",
							title: "Scope",
							body: "Armed control opens public guides only.",
							on: armed
						})
					]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto grid max-w-6xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl",
							children: "Catalog"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [visible.length, " records"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 flex flex-wrap gap-2",
						children: GROUPS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setGroup(item.id),
							className: `rounded-full border px-3 py-2 text-sm ${group === item.id ? "border-accent bg-accent text-accent-ink" : "border-rule bg-panel text-ink"}`,
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-3",
						children: visible.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-card border border-rule bg-panel p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-serif text-xl leading-tight",
										children: tool.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `rounded-full px-2 py-1 text-xs ${tool.gated ? "bg-hold-bg text-hold" : "bg-paper text-muted"}`,
										children: [AUTH_LABEL[tool.auth], tool.gated ? " · held" : " · open"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-ink",
									children: tool.use
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted",
									children: tool.access
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => openGated(tool.href, tool.name),
									className: "mt-3 inline-flex min-h-11 items-center gap-2 text-sm font-medium text-accent",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" }), tool.gated && !armed ? `Hold ${tool.hrefLabel}` : tool.hrefLabel]
								})
							]
						}, tool.id))
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "min-w-0 lg:sticky lg:top-4 lg:self-start",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-card border border-rule bg-panel p-4 sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "mt-1 size-5 shrink-0 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-2xl",
								children: "LeapSpace desk"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-muted",
								children: "Elsevier tool on the library ScienceDirect subscription. Log in with your HKBU email on the library path. Standard mode for a referenced answer; Deep Research only if your quota allows. Funding index is about 45,000 calls."
							})] })]
						}),
						!armed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "mt-4 space-y-3 border-t border-rule pt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("legend", {
									className: "flex items-center gap-2 font-sans text-sm font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4 text-warn" }), "Arm control before the LeapSpace path"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-start gap-3 text-sm leading-relaxed",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										className: "mt-1 size-4 accent-accent",
										checked: confirmHonest,
										onChange: (event) => setConfirmHonest(event.target.checked)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I understand this app will not authenticate as me and will not present simulated LeapSpace, Scopus, or ScienceDirect results." })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-start gap-3 text-sm leading-relaxed",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										className: "mt-1 size-4 accent-accent",
										checked: confirmSelf,
										onChange: (event) => setConfirmSelf(event.target.checked)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I will sign in myself, with my own HKBU email, only on the library ScienceDirect page." })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: !confirmHonest || !confirmSelf,
									onClick: arm,
									className: "inline-flex min-h-11 items-center rounded-full bg-accent px-4 text-sm font-medium text-accent-ink disabled:opacity-40",
									children: "Arm control and unlock the desk"
								}),
								!hydrated ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "Control stays on this browser until you revoke it."
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-3 border-t border-rule pt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-2",
									children: LEAP_INTENTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											setIntent(item.id);
											setQuestion(item.prompt);
										},
										className: `rounded-full border px-3 py-2 text-sm ${intent === item.id ? "border-accent bg-accent text-accent-ink" : "border-rule bg-paper"}`,
										children: item.label
									}, item.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-sm font-medium",
									htmlFor: "leap-q",
									children: "Question you will paste after you sign in"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "leap-q",
									value: question,
									onChange: (event) => setQuestion(event.target.value),
									rows: 6,
									className: "w-full rounded-card border border-rule bg-paper p-3 text-sm leading-relaxed outline-none focus:border-accent"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: copyPacket,
											className: "inline-flex min-h-11 items-center gap-2 rounded-full bg-accent px-4 text-sm font-medium text-accent-ink",
											children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied ? "Copied" : "Copy four-part packet"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => openGated("https://hkbu.libguides.com/az/databases?q=ScienceDirect", "ScienceDirect A–Z"),
											className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-rule px-4 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" }), "ScienceDirect in A–Z"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => openGated("https://hkbu.libguides.com/leapspace/access", "LeapSpace access"),
											className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-rule px-4 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" }), "Access guide"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: revoke,
											className: "inline-flex min-h-11 items-center rounded-full px-3 text-sm text-warn",
											children: "Revoke control"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
									className: "max-h-80 overflow-auto rounded-card border border-rule bg-paper p-3 font-sans text-xs leading-relaxed whitespace-pre-wrap",
									children: packet
								})
							]
						}),
						scopeNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 rounded-card bg-hold-bg px-3 py-2 text-sm text-hold",
							role: "status",
							children: scopeNote
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs leading-relaxed text-muted",
							children: "Sources checked as public pages: LeapSpace guide (22 Apr 2026), library subscription note (access via ScienceDirect), Consensus guide (31 Aug 2026), OpenAthens e-resources guide, generative-AI tool list, and the research-support service page. The library does not support the open tools on that list, and licensed full text must not be uploaded to them."
						})
					]
				})
			})]
		})]
	});
}
function Node({ n, title, body, on }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: `rounded-card border px-3 py-3 ${on ? "border-accent bg-paper" : "border-rule bg-paper"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs tracking-wide text-muted uppercase",
				children: ["Node ", n]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-serif text-lg leading-tight",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs leading-relaxed text-muted",
				children: body
			})
		]
	});
}
var SplitComponent = ResearchGate;
//#endregion
export { SplitComponent as component };
